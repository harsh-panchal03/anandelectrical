# Online-ticket-booking

## Project Link - http://travellerportal.epizy.com

1. The System adds Bus & Routes (source and destination) with in the Range of Service Provided
2. The System adds Bus (name of driver, depart time, arrival time ,charges for stages)
3. The System generates an Id card instantly after adding the Driver to particular bus and route.
4. The Added Routes, Busses and Stages will be available with Modification Option as Mandatory
5. The System enables customers to book Bus ticket through different interface & Admin Interface.
6. Ticket will be downloaded to customers after ticket is confirmed.
